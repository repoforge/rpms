#include "imagelistitem.h"

KIFImageListItem::KIFImageListItem(QListBox *listbox, const QString &path)
    : QListBoxText(listbox, path)
{
    ;
}

KIFImageListItem::~KIFImageListItem()
{
    ;
}

QString KIFImageListItem::fileName()
{
    return(text()); // hack from old KURL version
}


