#ifndef __KIF_COMPLETION_H
#define __KIF_COMPLETION_H

// This can scan the items in the browser window for filename
// completion, which is particulary fast since folders are always
// sorted on top :)

#include <kcompletion.h>
class PixieBrowser;

class PixieComp : public KCompletion
{
public:
    PixieComp(PixieBrowser *b);
    ~PixieComp();
    QString makeCompletion(const QString &str);
protected:
    PixieBrowser *browser;
    QString currentPath;
};

#endif


