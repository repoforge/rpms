#ifndef __KIF_IMAGEBUFFER_H
#define __KIF_IMAGEBUFFER_H

#include <qobject.h>
#include <qimage.h>

void adjustAlpha(QImage &img);

class KIFImage : public QObject
{
    Q_OBJECT
public:
    KIFImage(QObject *parent=0, const char *name=0);
    ~KIFImage();
    QImage* image(){return(&mainImg);}
    void setImage(QImage *img);
public slots:
    void slotSetFile(const QString &fileStr);
    void slotUpdateFromImage();
signals:
    void updated();
    void invalidFile();
protected:
    QImage mainImg;
};



#endif

