#ifndef __KIF_ATTRIBUTEDIALOG_H
#define __KIF_ATTRIBUTEDIALOG_H

#include <qdialog.h>
class KIntNumInput;
class QTextEdit;

class KIFAttributeDialog : public QDialog
{
    Q_OBJECT
public:
    KIFAttributeDialog(bool supportComment, QWidget *parent=0,
                       const char *name=0);
    int quality();
    QString comment();
protected:
    KIntNumInput *qualityInput;
    QTextEdit *commentEdit;
};


#endif

