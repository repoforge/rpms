#ifndef __PIXIE_JPEGTRANSFORM_H
#define __PIXIE_JPEGTRANSFORM_H

class QBuffer;

enum JPEGTransform{JPEGRot90=0, JPEGRot180, JPEGRot270, JPEGFlipH,
    JPEGFlipV, JPEGProgressive};

/* This transforms the JPEG and writes the output to the buffer so you can
 * preview it before saving */
bool transformJPEG(const char *filename, QBuffer *output,
                   JPEGTransform transform);

#endif

