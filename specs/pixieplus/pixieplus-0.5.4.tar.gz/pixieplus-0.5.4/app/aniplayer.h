#ifndef __KIF_ANIPLAYER_H
#define __KIF_ANIPLAYER_H

#include <qwidget.h>
#include <qmovie.h>
#include <qvariant.h>
#include <qdir.h>
#include <X11/X.h>
#include <X11/Xlib.h>


class KIFAniPlayer : public QWidget
{
    Q_OBJECT
public:
    KIFAniPlayer(const QString &filename, QWidget *parent=0,
                 const char *name=0);
    ~KIFAniPlayer();
protected slots:
    void slotUpdate();
protected:
    void paintEvent(QPaintEvent *ev);
    void mousePressEvent(QMouseEvent *ev);

    QMovie *movie;
    QColor c;
    GC gc;

};


#endif

