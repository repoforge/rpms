#ifndef __PIXIE_DIRTREE_H
#define __PIXIE_DIRTREE_H

#include <kfiletreeview.h>


class PixieDirTree : public KFileTreeView
{
    Q_OBJECT
public:
    PixieDirTree(QWidget *parent=0, const char *name=0);
    ~PixieDirTree();
signals:
    void locationChanged(const QString &);
protected:
    bool acceptDrag(QDropEvent *event) const;
protected slots:
    void slotDropped(KFileTreeView *, QDropEvent *, QListViewItem *);
    void slotCurrentChanged(QListViewItem *);
};

#endif

