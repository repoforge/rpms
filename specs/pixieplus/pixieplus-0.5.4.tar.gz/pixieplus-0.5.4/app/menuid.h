#ifndef __KIF_MENUID_H
#define __KIF_MENUID_H

enum FileMenuID{NewWindowID=0, ScreenShotID, SlideShowID, GalleryID,
SimiliarID, EditCatID, Pixie2KonqID, Konq2PixieID, NewFolderID,
PageLayoutID, PrintID, OpenFileListID, SaveFileListID,
SaveFileListAsID, QuitID};

enum EditMenuID{CopyID=0, PasteID, SelectAllID, UnselectAllID};

enum SortMenuID{AscendingByNameID=0, DescendingByNameID,
AscendingByDateID, DescendingByDateID,
AscendingBySizeID, DescendingBySizeID,
AscendingSameSizesFirstID, ImagesOnTopID, CatOnTopID, ImageOnlyID};

enum ViewMenuID{InternalPreviewID=0, LowQualityPreviewID, EmbedJPEGPreviewID,
EmbedTIFFPreviewID, TextPreviewID, ClipartPreviewID, PSPDFPreviewID,
KOfficePreviewID, OfficePreviewID, ArchivePreviewID, HTMLPreviewID,
SoundPreviewID};

enum VideoMenuID{VideoPreviewID=0, VideoKDEID, VideoMPlayerID};

enum ImageMenuID{ScaledWindowID=0, ScrollWindowID, FullscreenID,
FullscreenMaxpectID, FullscreenColorID};

enum SizeMenuID{SmallID=0, MediumID, LargeID, HugeID};

enum SlideShowEffectID{NoSlideEffectID=0, BlendSlideEffectID,
FadeSlideEffectID, HorizontalSlideEffectID, VerticalSlideEffectID};

enum RMBMenuID{ConvertRMB=0, BatchRMB, CopyRMB, PasteRMB, CopySelToFileListRMB,
CopyAllToFileListRMB, CopyFilePathRMB, CopyFileLocationRMB,
RenameRMB, DeleteRMB, PropertiesRMB, PlayAniRMB, CatagoryRMB,
MakeOldestRMB, MakeNewestRMB, SelectAllRMB, UnselectAllRMB, WipeRMB};

#endif

