#ifndef __KIF_IMAGELISTITEM_H
#define __KIF_IMAGELISTITEM_H

#include <qlistbox.h>

class KIFImageListItem : public QListBoxText
{
public:
    KIFImageListItem(QListBox *listbox, const QString &path);
    ~KIFImageListItem();
    QString fileName();
};


#endif

