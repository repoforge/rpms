// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef ELC_PRIVATE_H
#define ELC_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"0.9.9.0"
#define VER_MAJOR	0
#define VER_MINOR	9
#define VER_RELEASE	9
#define VER_BUILD	0
#define COMPANY_NAME	""
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"Eternal-Lands Client"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Eternal-Lands Client"
#define PRODUCT_VERSION	"0.9.9"

#endif //ELC_PRIVATE_H
