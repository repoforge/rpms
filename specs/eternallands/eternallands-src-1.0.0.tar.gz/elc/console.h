#ifndef __CONSOLE_H__
#define __CONSOLE_H__

void cls();
void print_log();
void test_for_console_command();
#endif
