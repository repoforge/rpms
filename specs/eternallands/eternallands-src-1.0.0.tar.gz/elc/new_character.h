#ifndef __NEW_CHARACTER_H__
#define __NEW_CHARACTER_H__

void change_actor();
void check_for_input();
void draw_new_char_screen();
void add_char_2_pass(unsigned char ch);
void add_char_2_un(unsigned char ch);
void add_char_2_conf(unsigned char ch);
void add_char_to_new_character(unsigned char ch);
void login_from_new_char();

#endif
