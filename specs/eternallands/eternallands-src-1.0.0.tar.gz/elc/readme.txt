To compile under Linux (and other Unix like OSes, edit global.h and comment the #define WINDOWS line)
Please read the eternal_lands_license.txt, which governs the source code.
