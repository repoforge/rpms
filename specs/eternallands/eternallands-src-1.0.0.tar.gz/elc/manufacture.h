#ifndef __MANUFACTURE_H__
#define __MANUFACTURE_H__

extern int manufacture_win;
void build_manufacture_list();
void display_manufacture_menu();
//int check_manufacture_interface();

#endif
